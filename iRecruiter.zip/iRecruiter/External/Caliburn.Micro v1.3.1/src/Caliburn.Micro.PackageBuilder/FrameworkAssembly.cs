namespace Caliburn.Micro.PackageBuilder {
    public class FrameworkAssembly {
        public string Name { get; set; }
        public string Target { get; set; }
    }
}