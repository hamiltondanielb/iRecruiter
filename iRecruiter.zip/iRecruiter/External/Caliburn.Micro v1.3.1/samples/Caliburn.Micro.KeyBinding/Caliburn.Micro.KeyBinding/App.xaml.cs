﻿namespace Caliburn.Micro.KeyBinding 
{
    using System.Windows;

    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application {}
}