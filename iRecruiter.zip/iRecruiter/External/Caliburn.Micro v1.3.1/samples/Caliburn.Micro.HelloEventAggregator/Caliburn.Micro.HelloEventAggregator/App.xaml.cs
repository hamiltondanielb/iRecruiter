﻿namespace Caliburn.Micro.HelloEventAggregator {
    using System.Windows;

    public partial class App : Application {
        public App() {
            InitializeComponent();
        }
    }
}