﻿namespace Caliburn.Micro.HelloEventAggregator {
    public class RightEvent {
        public int Number;

        public override string ToString() {
            return "Right " + Number;
        }
    }
}