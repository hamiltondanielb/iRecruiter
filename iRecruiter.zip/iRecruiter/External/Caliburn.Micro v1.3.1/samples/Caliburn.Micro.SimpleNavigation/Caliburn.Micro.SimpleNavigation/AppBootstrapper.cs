﻿namespace Caliburn.Micro.SimpleNavigation {
    public class AppBootstrapper : Bootstrapper<ShellViewModel> {}
}