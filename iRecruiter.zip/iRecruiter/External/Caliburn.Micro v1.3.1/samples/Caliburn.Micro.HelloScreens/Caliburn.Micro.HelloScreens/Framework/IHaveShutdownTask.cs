namespace Caliburn.Micro.HelloScreens.Framework {
    public interface IHaveShutdownTask {
        IResult GetShutdownTask();
    }
}