﻿namespace Caliburn.Micro.HelloScreens {
    public interface IShell {}
}
