﻿namespace Caliburn.Micro.HelloScreens {
    using System.Windows;

    public partial class App : Application {
        public App() {
            InitializeComponent();
        }
    }
}