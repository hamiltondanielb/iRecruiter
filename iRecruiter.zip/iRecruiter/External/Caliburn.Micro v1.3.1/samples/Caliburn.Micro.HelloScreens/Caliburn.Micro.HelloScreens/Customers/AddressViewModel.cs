﻿namespace Caliburn.Micro.HelloScreens.Customers
{
    public class AddressViewModel : Screen
    {
        public AddressViewModel() {
            DisplayName = "Address";
        }
    }
}