﻿namespace Caliburn.Micro.Coroutines.External
{
    using System.Windows.Controls;

    public partial class ExternalScreenView : UserControl
    {
        public ExternalScreenView()
        {
            InitializeComponent();
        }
    }
}