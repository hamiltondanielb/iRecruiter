﻿namespace Caliburn.Micro.HelloWindowManager {
    using System.ComponentModel.Composition;

    [Export(typeof(IShell))]
    public class ShellViewModel : IShell {}
}
