namespace Caliburn.Micro.HelloWindowManager {
    public interface IShell {
        
    }
}