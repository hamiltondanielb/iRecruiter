﻿namespace GameLibrary.Resources
{
    using System.Windows.Controls;

    public partial class Background : UserControl
    {
        public Background()
        {
            InitializeComponent();
        }
    }
}