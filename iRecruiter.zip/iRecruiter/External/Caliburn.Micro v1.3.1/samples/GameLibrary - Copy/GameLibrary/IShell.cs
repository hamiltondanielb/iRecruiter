﻿namespace GameLibrary {
    public interface IShell {}
}
