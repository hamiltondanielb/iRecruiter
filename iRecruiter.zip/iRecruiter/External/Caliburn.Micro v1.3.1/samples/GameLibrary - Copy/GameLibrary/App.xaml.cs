﻿namespace GameLibrary {
    public partial class App {
        public App() {
            InitializeComponent();
        }
    }
}