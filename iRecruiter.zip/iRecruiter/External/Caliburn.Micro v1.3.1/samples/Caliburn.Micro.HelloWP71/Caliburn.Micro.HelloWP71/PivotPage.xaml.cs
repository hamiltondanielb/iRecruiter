﻿namespace Caliburn.Micro.HelloWP71 {
    public partial class PivotPage {
        public PivotPage() {
            InitializeComponent();
        }
    }
}