﻿namespace Caliburn.Micro.BubblingAction
{
    using System;

    public class Model
    {
        public Guid Id { get; set; }
    }
}