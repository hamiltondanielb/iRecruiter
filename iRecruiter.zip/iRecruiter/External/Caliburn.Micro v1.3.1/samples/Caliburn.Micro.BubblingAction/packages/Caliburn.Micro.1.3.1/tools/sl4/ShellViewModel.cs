﻿namespace Caliburn.Micro.BubblingAction {
    using System.ComponentModel.Composition;

    [Export(typeof(IShell))]
    public class ShellViewModel : IShell {}
}
