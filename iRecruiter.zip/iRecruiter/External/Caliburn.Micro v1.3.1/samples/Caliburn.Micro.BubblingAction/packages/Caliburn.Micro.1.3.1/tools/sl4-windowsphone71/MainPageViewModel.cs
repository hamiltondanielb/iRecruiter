﻿namespace $safeprojectname$ {
    public class MainPageViewModel {}
}