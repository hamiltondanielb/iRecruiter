﻿using System;
using System.Net;
using System.Web.Mvc;
using CandidateLib;

namespace CandidateService.Controllers
{
    public class IosServiceController : Controller
    {
        [HttpGet]
        public ActionResult SyncData()
        {
            var db = new DataSyncService();
            {
                return Json(new
                            {
                                SyncTime = DateTime.UtcNow,
                                Questions = db.Questions(),
                                QuestionSets = db.QuestionSets(),
                                Locations = db.Locations(),
                                Events = db.Events(),
                                Teams = db.Teams(),
                                Skills = db.Skills()
                            }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public ActionResult GetCandidates()
        {
            var db = new DataSyncService();
            {
                return Json(db.Candidates(), JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult PostCandidates(EFData.Candidate[] candidate)
        {
            var db = new DataSyncService();
            {
                return db.AddCandidates(candidate) ? 
                    new HttpStatusCodeResult((int)HttpStatusCode.OK) : 
                    new HttpStatusCodeResult((int)HttpStatusCode.BadRequest);
            }
        }
    }
}
