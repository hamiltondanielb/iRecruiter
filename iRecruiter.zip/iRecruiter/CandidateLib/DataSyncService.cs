﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using EFData;

namespace CandidateLib
{
    public class DataSyncService : IRemoteSyncService
    {
        #region IRemoteSyncService Members
        
        public Skill[] Skills()
        {
            try
            {
                using (var db = new iRecruiterEntities())
                {
                    db.Configuration.ProxyCreationEnabled = false;
                    return db.Skills.ToArray();
                }
            }
            catch
            {
                return new Skill[0];
            }
        }

        public Location[] Locations()
        {
            try
            {
                using (var db = new iRecruiterEntities())
                {
                    db.Configuration.ProxyCreationEnabled = false;
                    return db.Locations.ToArray();
                }
            }
            catch
            {
                return new Location[0];
            }
        }

        public Event[] Events()
        {
            try
            {
                using (var db = new iRecruiterEntities())
                {
                    db.Configuration.ProxyCreationEnabled = false;
                    return db.Events.ToArray();
                }
            }
            catch
            {
                return new Event[0];

            }
        }

        public Team[] Teams()
        {
            try
            {
                using (var db = new iRecruiterEntities())
                {
                    db.Configuration.ProxyCreationEnabled = false;
                    return db.Teams.ToArray();
                }
            }
            catch
            {
                return new Team[0];
            }

        }


        public QuestionSet[] QuestionSets()
        {
            try
            {
                using (var db = new iRecruiterEntities())
                {
                    db.Configuration.ProxyCreationEnabled = false;
                    return db.QuestionSets.ToArray();
                }
            }
            catch
            {
                return new QuestionSet[0];
            }

        }

        public Question[] Questions()
        {
            try
            {
                using (var db = new iRecruiterEntities())
                {
                    db.Configuration.ProxyCreationEnabled = false;
                    return db.Questions.ToArray();
                }
            }
            catch
            {
                return new Question[0];
            }

        }
    
        public Candidate[] Candidates()
        {
            try
            {
                using (var db = new iRecruiterEntities())
                {
                    db.Configuration.ProxyCreationEnabled = false;
                    return db.Candidates.ToArray();
                }
            }
            catch
            {
                return new Candidate[0];
            }
        }
        
        public bool AddCandidates(Candidate[] candidates)
        {
            try
            {
                using (var db = new iRecruiterEntities())
                {
                    foreach (var candidate in candidates)
                    {
                        try
                        {
                            db.Candidates.Add(candidate);
                        }
                        catch {}
                    }
                    
                    db.SaveChanges();
                }

            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        #endregion
    }
}
