﻿using EFData;

namespace CandidateLib
{
    public interface IRemoteSyncService
    {
        Skill[] Skills();
        Location[] Locations();
        Event[] Events();
        Team[] Teams();
        QuestionSet[] QuestionSets();
        Question[] Questions();
        Candidate[] Candidates();

        bool AddCandidates(Candidate[] candidates);
    }
}
