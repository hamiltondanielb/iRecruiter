﻿using System;
using System.Drawing;
using System.IO;
using System.Reactive.Linq;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OfficeOpenXml;
using OfficeOpenXml.Style;

namespace Client.Tests
{
    [TestClass]
    public class ExcelTests
    {
        
        public ExcelTests()
        {
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void GenerateExcel()
        {
            for (int i = 1; i <= 19; i++)
            {
                CreateExcelForJobvite(i);
            }
        }

        private void CreateExcelForJobvite(int EventID = 1)
        {

            var DB = new CandidateLib.DataSyncService();
            string eventName = DB.Events().First(e => e.EventID == EventID).Name;


            FileInfo newFile = new FileInfo(@"d:\share\CandidateOutput\Event - " + eventName + @".xlsx");

            if (newFile.Exists)
                newFile.Delete();

            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                //Add the Content sheet
                var ws = package.Workbook.Worksheets.Add("Candidates");
                ws.View.ShowGridLines = false;

                //Headers
                ws.Cells["A1"].Value = "First Name";
                ws.Cells["B1"].Value = "Last Name";
                ws.Cells["C1"].Value = "Company";
                ws.Cells["D1"].Value = "Job Title";
                ws.Cells["E1"].Value = "Tags";
                ws.Cells["F1"].Value = "Notes";
                ws.Cells["F1"].Style.WrapText = true;
                ws.Cells["G1"].Value = "Source Type";
                ws.Cells["H1"].Value = "Source Name";
                ws.Cells["I1"].Value = "Email";
                ws.Cells["J1"].Value = "Email 2";
                ws.Cells["K1"].Value = "Email 3";
                ws.Cells["L1"].Value = "Home Phone";
                ws.Cells["M1"].Value = "Cell Phone";
                ws.Cells["N1"].Value = "Work Phone";
                ws.Cells["O1"].Value = "Address 1";
                ws.Cells["P1"].Value = "Address 2";
                ws.Cells["Q1"].Value = "City";
                ws.Cells["R1"].Value = "State/Province";
                ws.Cells["S1"].Value = "Zip/Postal";
                ws.Cells["T1"].Value = "Country";
                ws.Cells["U1"].Value = "URL1";
                ws.Cells["V1"].Value = "Facebook";
                ws.Cells["W1"].Value = "LinkedIn";
                ws.Cells["X1"].Value = "Twitter";
                ws.Cells["A1:X1"].Style.Font.Bold = true;



                int row = 2;
                foreach (var c in DB.Candidates().Where(c => c.EventID == EventID))
                {
                    var names = c.Name.Split(' ');

                    ws.Cells[row, 1].Value = names != null ? names[0] : "Unknown";
                    ws.Cells[row, 2].Value = names != null && names.Count() > 1 ? names[1] : string.Empty;
                    ws.Cells[row, 3].Value = "Event - " + eventName;
                    ws.Cells[row, 4].Value = "Team Preference - " + BuildPreferredTeams(DB, c);
                    ws.Cells[row, 5].Value = BuildImportanceLevel(c);
                    ws.Cells[row, 6].Value = BuildNotesField(DB, c);
                    ws.Cells[row, 9].Value = c.EmailAddress;
                    row++;
                }

                // Change the sheet view to show it in page layout mode
                ws.View.PageLayoutView = true;

                // save our new workbook and we are done!
                package.Save();
            }
            


        }

        private string BuildNotesField(CandidateLib.DataSyncService DB, EFData.Candidate c)
        {
            var sb = new StringBuilder();

            string location = "Unspecified";

            try
            {
                var locations = DB.Locations();
                if (locations.Any())
                {
                    location = locations.First(l => l.LocationID == c.PreferredLocationID).Name;
                }
            }
            catch
            {
            }

            sb.AppendFormat("Screener: {0}", c.Screener);
            sb.AppendLine("\r\n").AppendFormat("Graduation Date: {0}", c.GraduationDate);
            sb.AppendLine("\r\n").AppendFormat("Major: {0}", c.Major);
            sb.AppendLine("\r\n").AppendFormat("Overall GPA: {0}", c.OverallGPA);
            sb.AppendLine("\r\n").AppendFormat("Major GPA: {0}", c.MajorGPA);
            sb.AppendLine("\r\n").AppendFormat("Communication Skills: {0}/5", c.CommunicationSkills);
            sb.AppendLine("\r\n").AppendFormat("Skills: {0}", c.Skills);
            sb.AppendLine("\r\n").AppendFormat("Preferred Location: {0}", location);
            sb.AppendLine("\r\n").AppendFormat("Screener Notes: {0}", c.Notes);
            sb.AppendLine("\r\n").AppendFormat("Question Results:").AppendLine().AppendLine(BuildQuestionResults(DB, c));

            return sb.ToString();
        }

        private string BuildImportanceLevel(EFData.Candidate c)
        {
            switch (c.ImportanceLevel)
            {
                case 1:
                    return "Chili Pepper!";
                case 2:
                    return "Phone Screen!";
                default:
                    return string.Empty;
            }
        }

        private string BuildPreferredTeams(CandidateLib.DataSyncService DB, EFData.Candidate c)
        {
            string noPreference = "No Preference";
            if (string.IsNullOrWhiteSpace(c.PreferredTeams) || c.PreferredTeams == "NULL")
            {
                return noPreference;
            }

            var teams = c.PreferredTeams.Split(',');

            // check to make sure all are valid
            foreach (var t in teams)
            {
                int testInt = 0;
                if (!int.TryParse(t, out testInt))
                {
                    return noPreference;
                }
            }

            if (teams.Length == 1)
            {
                return DB.Teams().First(t => t.TeamID == Convert.ToInt32(teams[0])).Name;
            }

            var sb = new StringBuilder();
            for (int i = 0; i < teams.Length; i++)
            {
                sb.Append(DB.Teams().First(t => t.TeamID == Convert.ToInt32(teams[i])).Name);
                if (i < teams.Length - 1)
                {
                    sb.Append(", ");
                }
            }

            return sb.ToString();
        }

        private string BuildQuestionResults(CandidateLib.DataSyncService DB, EFData.Candidate c)
        {
            string noValue = "Not Used by Screener";
            if (string.IsNullOrWhiteSpace(c.QuestionResults) || c.PreferredTeams == "NULL")
            {
                return noValue;
            }

            var questions = c.QuestionResults.Split(',');

            var sb = new StringBuilder();
            foreach (var t in questions)
            {
                try
                {
                    var QAresults = t.Split('-');

                    int questionId = -1;
                    int questionResult = -1;
                    if (!int.TryParse(QAresults[0], out questionId) || !int.TryParse(QAresults[1], out questionResult))
                    {
                        return noValue;
                    }

                    if (questionId > 0 && questionResult > 0)
                    {
                        var question = DB.Questions().FirstOrDefault(q => q.QuestionID == questionId);
                        if (question != null)
                        {
                            sb.AppendLine(question.Title).AppendLine(String.Format("Score: {0}", questionResult)).AppendLine();
                        }
                    }
                }
                catch (Exception)
                {
                    return noValue;
                }
            }

            return String.IsNullOrEmpty(sb.ToString()) ? noValue : sb.ToString();
        }
    }
}
