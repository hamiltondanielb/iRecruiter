USE [iRecruiter]
GO

ALTER TABLE [dbo].[TeamInterestedMajor] DROP CONSTRAINT [FK_TeamInterestedMajor_Team_TeamID]
GO

ALTER TABLE [dbo].[TeamInterestedMajor] DROP CONSTRAINT [FK_TeamInterestedMajor_Major_MajorID]
GO

/****** Object:  Table [dbo].[TeamInterestedMajor]    Script Date: 8/16/2012 10:31:47 AM ******/
DROP TABLE [dbo].[TeamInterestedMajor]
GO

/****** Object:  Table [dbo].[TeamInterestedMajor]    Script Date: 8/16/2012 10:31:47 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TeamInterestedMajor](
	[TeamInterestedMajorID] [int] IDENTITY(1,1) NOT NULL,
	[TeamID] [int] NOT NULL,
	[MajorID] [int] NOT NULL,
 CONSTRAINT [PK_TeamInterestedMajor] PRIMARY KEY CLUSTERED 
(
	[TeamInterestedMajorID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[TeamInterestedMajor]  WITH CHECK ADD  CONSTRAINT [FK_TeamInterestedMajor_Major_MajorID] FOREIGN KEY([MajorID])
REFERENCES [dbo].[Major] ([MajorID])
GO

ALTER TABLE [dbo].[TeamInterestedMajor] CHECK CONSTRAINT [FK_TeamInterestedMajor_Major_MajorID]
GO

ALTER TABLE [dbo].[TeamInterestedMajor]  WITH CHECK ADD  CONSTRAINT [FK_TeamInterestedMajor_Team_TeamID] FOREIGN KEY([TeamID])
REFERENCES [dbo].[Team] ([TeamID])
GO

ALTER TABLE [dbo].[TeamInterestedMajor] CHECK CONSTRAINT [FK_TeamInterestedMajor_Team_TeamID]
GO

