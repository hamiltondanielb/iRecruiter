USE [iRecruiter]
GO

ALTER TABLE [dbo].[QuestionResult] DROP CONSTRAINT [FK_QuestionResult_Question_QuestionID]
GO

ALTER TABLE [dbo].[QuestionResult] DROP CONSTRAINT [FK_QuestionResult_Candidate_CandidateID]
GO

/****** Object:  Table [dbo].[QuestionResult]    Script Date: 8/16/2012 10:31:19 AM ******/
DROP TABLE [dbo].[QuestionResult]
GO

/****** Object:  Table [dbo].[QuestionResult]    Script Date: 8/16/2012 10:31:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[QuestionResult](
	[QuestionResultID] [int] IDENTITY(1,1) NOT NULL,
	[QuestionID] [int] NOT NULL,
	[CandidateID] [int] NOT NULL,
	[ResultScore] [int] NOT NULL,
 CONSTRAINT [PK_QuestionResult] PRIMARY KEY CLUSTERED 
(
	[QuestionResultID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[QuestionResult]  WITH CHECK ADD  CONSTRAINT [FK_QuestionResult_Candidate_CandidateID] FOREIGN KEY([CandidateID])
REFERENCES [dbo].[Candidate] ([CandidateID])
GO

ALTER TABLE [dbo].[QuestionResult] CHECK CONSTRAINT [FK_QuestionResult_Candidate_CandidateID]
GO

ALTER TABLE [dbo].[QuestionResult]  WITH CHECK ADD  CONSTRAINT [FK_QuestionResult_Question_QuestionID] FOREIGN KEY([QuestionID])
REFERENCES [dbo].[Question] ([QuestionID])
GO

ALTER TABLE [dbo].[QuestionResult] CHECK CONSTRAINT [FK_QuestionResult_Question_QuestionID]
GO

