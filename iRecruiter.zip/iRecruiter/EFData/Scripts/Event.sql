USE [iRecruiter]
GO

/****** Object:  Table [dbo].[Event]    Script Date: 8/16/2012 10:30:43 AM ******/
DROP TABLE [dbo].[Event]
GO

/****** Object:  Table [dbo].[Event]    Script Date: 8/16/2012 10:30:43 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Event](
	[EventID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](256) NOT NULL,
	[Description] [nvarchar](4000) NULL,
	[Address] [nvarchar](4000) NULL,
 CONSTRAINT [PK_Event] PRIMARY KEY CLUSTERED 
(
	[EventID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

