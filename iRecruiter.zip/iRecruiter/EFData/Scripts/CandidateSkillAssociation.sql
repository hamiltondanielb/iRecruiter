USE [iRecruiter]
GO

ALTER TABLE [dbo].[CandidateSkillAssociation] DROP CONSTRAINT [FK_CandidateSkillAssociation_Skill]
GO

ALTER TABLE [dbo].[CandidateSkillAssociation] DROP CONSTRAINT [FK_CandidateSkill_CandidateID]
GO

/****** Object:  Table [dbo].[CandidateSkillAssociation]    Script Date: 8/16/2012 10:30:37 AM ******/
DROP TABLE [dbo].[CandidateSkillAssociation]
GO

/****** Object:  Table [dbo].[CandidateSkillAssociation]    Script Date: 8/16/2012 10:30:37 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CandidateSkillAssociation](
	[CandidateSkillID] [int] IDENTITY(1,1) NOT NULL,
	[CandidateID] [int] NOT NULL,
	[SkillID] [int] NOT NULL,
 CONSTRAINT [PK_CandidateSkill] PRIMARY KEY CLUSTERED 
(
	[CandidateSkillID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[CandidateSkillAssociation]  WITH CHECK ADD  CONSTRAINT [FK_CandidateSkill_CandidateID] FOREIGN KEY([CandidateID])
REFERENCES [dbo].[Candidate] ([CandidateID])
GO

ALTER TABLE [dbo].[CandidateSkillAssociation] CHECK CONSTRAINT [FK_CandidateSkill_CandidateID]
GO

ALTER TABLE [dbo].[CandidateSkillAssociation]  WITH CHECK ADD  CONSTRAINT [FK_CandidateSkillAssociation_Skill] FOREIGN KEY([SkillID])
REFERENCES [dbo].[Skill] ([SkillID])
GO

ALTER TABLE [dbo].[CandidateSkillAssociation] CHECK CONSTRAINT [FK_CandidateSkillAssociation_Skill]
GO

