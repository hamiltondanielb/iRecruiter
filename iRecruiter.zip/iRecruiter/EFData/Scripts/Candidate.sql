USE [iRecruiter]
GO

ALTER TABLE [dbo].[Candidate] DROP CONSTRAINT [FK_Candidate_Team_TeamID]
GO

ALTER TABLE [dbo].[Candidate] DROP CONSTRAINT [FK_Candidate_MajorID]
GO

ALTER TABLE [dbo].[Candidate] DROP CONSTRAINT [FK_Candidate_Location_LocationID]
GO

ALTER TABLE [dbo].[Candidate] DROP CONSTRAINT [FK_Candidate_Event_EventID]
GO

/****** Object:  Table [dbo].[Candidate]    Script Date: 8/16/2012 10:30:12 AM *****/
DROP TABLE [dbo].[Candidate]
GO

/****** Object:  Table [dbo].[Candidate]    Script Date: 8/16/2012 10:30:12 AM *****/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Candidate](
	[CandidateID] [int] IDENTITY(1,1) NOT NULL,
	[Screener] [nvarchar](512) NOT NULL,
	[Name] [nvarchar](512) NOT NULL,
	[EmailAddress] [nvarchar](1024) NOT NULL,
	[EventID] [int] NOT NULL,
	[MajorID] [int] NULL,
	[SponsershipNeeded] [bit] NULL,
	[OverallGPA] [float] NULL,
	[MajorGPA] [float] NULL,
	[GraduationDate] [date] NULL,
	[PreferredTeamID] [int] NULL,
	[PreferredLocationID] [int] NULL,
	[Notes] [nvarchar](max) NULL,
	[IsHotCandidate] [bit] NULL,
	[CommunicationSkills] [nvarchar](2048) NULL,
 CONSTRAINT [PK_Candidate] PRIMARY KEY CLUSTERED 
(
	[CandidateID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

ALTER TABLE [dbo].[Candidate]  WITH CHECK ADD  CONSTRAINT [FK_Candidate_Event_EventID] FOREIGN KEY([EventID])
REFERENCES [dbo].[Event] ([EventID])
GO

ALTER TABLE [dbo].[Candidate] CHECK CONSTRAINT [FK_Candidate_Event_EventID]
GO

ALTER TABLE [dbo].[Candidate]  WITH CHECK ADD  CONSTRAINT [FK_Candidate_Location_LocationID] FOREIGN KEY([PreferredLocationID])
REFERENCES [dbo].[Location] ([LocationID])
GO

ALTER TABLE [dbo].[Candidate] CHECK CONSTRAINT [FK_Candidate_Location_LocationID]
GO

ALTER TABLE [dbo].[Candidate]  WITH CHECK ADD  CONSTRAINT [FK_Candidate_MajorID] FOREIGN KEY([MajorID])
REFERENCES [dbo].[Major] ([MajorID])
GO

ALTER TABLE [dbo].[Candidate] CHECK CONSTRAINT [FK_Candidate_MajorID]
GO

ALTER TABLE [dbo].[Candidate]  WITH CHECK ADD  CONSTRAINT [FK_Candidate_Team_TeamID] FOREIGN KEY([PreferredTeamID])
REFERENCES [dbo].[Team] ([TeamID])
GO

ALTER TABLE [dbo].[Candidate] CHECK CONSTRAINT [FK_Candidate_Team_TeamID]
GO

