
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 08/21/2012 21:22:59
-- Generated from EDMX file: D:\projects\iRecruiter\EFData\iRecruiterModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [iRecruiter];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[Candidates]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Candidates];
GO
IF OBJECT_ID(N'[dbo].[Events]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Events];
GO
IF OBJECT_ID(N'[dbo].[Locations]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Locations];
GO
IF OBJECT_ID(N'[dbo].[Questions]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Questions];
GO
IF OBJECT_ID(N'[dbo].[Skills]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Skills];
GO
IF OBJECT_ID(N'[dbo].[Teams]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Teams];
GO
IF OBJECT_ID(N'[dbo].[QuestionSets]', 'U') IS NOT NULL
    DROP TABLE [dbo].QuestionSets;
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Candidates'
CREATE TABLE [dbo].[Candidates] (
    [CandidateID] int IDENTITY(1,1) NOT NULL,
    [Screener] nvarchar(512)  NOT NULL,
    [Name] nvarchar(512)  NOT NULL,
    [EmailAddress] nvarchar(1024)  NOT NULL,
    [EventID] int  NOT NULL,
    [Major] nvarchar(max)  NULL,
    [SponsorshipNeeded] bit  NULL,
    [OverallGPA] float  NULL,
    [MajorGPA] float  NULL,
    [GraduationDate] datetime  NULL,
    [PreferredLocationID] int  NULL,
    [QuestionSetID] int  NULL,
    [Notes] nvarchar(max)  NULL,
    [ImportanceLevel] int  NULL,
    [CommunicationSkills] int  NULL,
    [PreferredTeams] nvarchar(max)  NULL,
    [Skills] nvarchar(max)  NULL,
    [QuestionResults] nvarchar(max)  NULL
);
GO

-- Creating table 'Events'
CREATE TABLE [dbo].[Events] (
    [EventID] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(256)  NOT NULL,
	[Date] date NOT NULL,
	[SentToJobvite] bit NULL

);
GO

-- Creating table 'Locations'
CREATE TABLE [dbo].[Locations] (
    [LocationID] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(512)  NOT NULL
);
GO

-- Creating table 'Questions'
CREATE TABLE [dbo].[Questions] (
    [QuestionID] int IDENTITY(1,1) NOT NULL,
    [Title] nvarchar(max)  NOT NULL,
    [Answer] nvarchar(max)  NULL,
    [Difficulty] int  NOT NULL,
    [QuestionSetID] int  NOT NULL
);
GO

-- Creating table 'Skills'
CREATE TABLE [dbo].[Skills] (
    [SkillID] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(512)  NOT NULL
);
GO

-- Creating table 'Teams'
CREATE TABLE [dbo].[Teams] (
    [TeamID] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(256)  NOT NULL
);
GO

-- Creating table 'QuestionSets'
CREATE TABLE [dbo].[QuestionSets] (
    [QuestionSetID] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(max)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [CandidateID] in table 'Candidates'
ALTER TABLE [dbo].[Candidates]
ADD CONSTRAINT [PK_Candidates]
    PRIMARY KEY CLUSTERED ([CandidateID] ASC);
GO

-- Creating primary key on [EventID] in table 'Events'
ALTER TABLE [dbo].[Events]
ADD CONSTRAINT [PK_Events]
    PRIMARY KEY CLUSTERED ([EventID] ASC);
GO

-- Creating primary key on [LocationID] in table 'Locations'
ALTER TABLE [dbo].[Locations]
ADD CONSTRAINT [PK_Locations]
    PRIMARY KEY CLUSTERED ([LocationID] ASC);
GO

-- Creating primary key on [QuestionID] in table 'Questions'
ALTER TABLE [dbo].[Questions]
ADD CONSTRAINT [PK_Questions]
    PRIMARY KEY CLUSTERED ([QuestionID] ASC);
GO

-- Creating primary key on [SkillID] in table 'Skills'
ALTER TABLE [dbo].[Skills]
ADD CONSTRAINT [PK_Skills]
    PRIMARY KEY CLUSTERED ([SkillID] ASC);
GO

-- Creating primary key on [TeamID] in table 'Teams'
ALTER TABLE [dbo].[Teams]
ADD CONSTRAINT [PK_Teams]
    PRIMARY KEY CLUSTERED ([TeamID] ASC);
GO

-- Creating primary key on [QuestionSetID] in table 'QuestionSets'
ALTER TABLE [dbo].[QuestionSets]
ADD CONSTRAINT [PK_QuestionSets]
    PRIMARY KEY CLUSTERED ([QuestionSetID] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------




-- BEGIN iRecruiter Administration Sample Data Database Script 

USE [iRecruiter]
GO

INSERT INTO [dbo].[Events]
           ([Name],
		   [Date],
		   SentToJobvite)
     VALUES
           ('Purdue Computer Roundtable', '9-6-2012', 1)
GO

INSERT INTO [dbo].[Locations]
           ([Name])
     VALUES
           ('Indianapolis'),
		   ('Jacksonville'),
		   ('Raleigh'),
		   ('Montreal'),
		   ('Denver'),
		   ('Slough'),
		   ('Irvine'),
		   ('Lafayette Test Lab')
GO


INSERT INTO [dbo].[Skills]
           ([Name])
     VALUES
           ('C#'),
           ('C++'),
           ('ASP.NET'),
           ('Javascript'),
           ('Ruby'),
           ('Object Orienteted Dev'),
           ('Java')
GO

INSERT INTO [dbo].[Teams]
           ([Name])
     VALUES
           ('Dev - Client'),
           ('Dev - Media'),
           ('Dev - Process'),
           ('Dev - Telephony'),
           ('Dev - Applications'),
           ('Dev - Server'),
           ('Dev - Integrations'),
           ('Dev - Doc/Localization'),
           ('Testing - Automation'),
           ('Testing - Functionality'),
           ('Support'),
           ('CaaS'),
           ('PSO')
GO


INSERT INTO [dbo].[QuestionSets]
           ([Name])
     VALUES
           ('Development'),
           ('IT and Networking')
GO

INSERT INTO [dbo].[Questions]
           ([Title]
           ,[Answer]
           ,[Difficulty]
           ,[QuestionSetID])
     VALUES
           -- Development Questions
		   ('What is a Static Function/Method?', null, 2, 1),
           ('Are there restrictions on what can be done inside a static method?', null, 5, 1),
           ('What would you use a Static method for?', null, 3, 1),
           ('Can you have a Static Constructor?  What is it used for?', null, 6, 1),
           ('What is a Constructor?', null, 1, 1),
           ('What is a default constructor?', null, 3, 1),
           ('Can you overload constructors?', null, 3, 1),
           ('Are constructors inherited?', null, 7, 1),
           ('Can a constructor be private?', null, 8, 1),
           ('How would you instantiate a class with only a private constructor?', null, 9, 1),
           ('Is it legal to call a virtual method from within a constructor?', null, 10, 1),
           ('What are the various access levels on members of an object?', null, 4, 1),
           ('What is an Interface?', null, 3, 1),
           ('Can an Interface contain fields?', null, 4, 1),
           ('Can an Interface be instantiated?', null, 3, 1),
           ('Can an Interface derive from another interface?', null, 6, 1),
           ('How does a abstract class differ from an interface?', null, 8, 1),
           ('What is multiple inheritance? Is it legal in C#?', null, 6, 1),
           ('Can you inherit from two interfaces with the same method name and signature?', null, 10, 1),
           ('What is Polymorphism?', null, 5, 1),
           ('What is the difference between the Stack and the Heap?', null, 5, 1),
           ('What are Exceptions and how are they used?', null, 4, 1),
           ('What is the difference between reference types and value types(C#) or the difference between pointers v.s. reference?', null, 7, 1),
           ('What do you know about multi-threaded applications?', null, 9, 1),

		   -- Testing Questions
           ('What does DNS stand for and what does it do?', null, 1, 2),
           ('How does traceroute work?', null, 3, 2),
           ('What is ARP?', null, 4, 2),
           ('What is SAS?', null, 5, 2),
           ('What are three main reasons for using RAID?', null, 6, 2),
           ('What are routing protocols? Why do we need them? Name a few.', null, 8, 2),
           ('What is a subnet?', null, 3, 2),
           ('When would you use a crossover cable?', null, 4, 2),
           ('What is the difference between TCP and UDP?', null, 3, 2),
           ('What is 255.255.255.255 used for?', null, 2, 2),
           ('How do L1, L2, and L3 work?', null, 7, 2),
           ('How do I look at the open ports on my machine?', null, 5, 2),
           ('What are the major advantages of working in a domain model?', null, 6, 2),
           ('What is Active Directory?', null, 4, 2),
           ('What is the Global Catalog?', null, 6, 2),
           ('What is virtualization (in general)?', null, 5, 2),
           ('How many logical CPUs does Hyper-V R2 support?', null, 10, 2),
           ('If you need to view network traffic, what tools could you use? Name a few tools.', null, 2, 2),
           ('Where would you look for Windows errors?', null, 1, 2)

GO

--INSERT INTO [dbo].[Candidates]
--           ([Screener]
--           ,[Name]
--           ,[EmailAddress]
--           ,[EventID]
--           ,[Major]
--           ,[SponsorshipNeeded]
--           ,[OverallGPA]
--           ,[MajorGPA]
--           ,[GraduationDate]
--           ,[PreferredTeams]
--		   ,[PreferredLocationID]
--		   ,[QuestionSetID]
--		   ,[Notes]
--           ,[ImportanceLevel]
--           ,[CommunicationSkills]
--           ,[Skills] 
--           ,[QuestionResults])
--VALUES
--           ('Bree Baxter', 'Test Candidate 1', 'joe.behymer@inin.com', 1, 'Computer Science', 0, 3.5, 3.7, '1-1-2013', '1,2', null, 1, 'decent candidate', 2, 5, '1,2,3', '1-5,2-7,3-4,4-3,5-8,6-9,7-10,8-4,9-2,10-5'),
--           ('Bree Baxter', 'Test Candidate 2', 'steve@outlook.com', 2, 'Human Computer Interfaces', 0, 3.7, 3.9, '7-1-2013', '1,3', null, 2, 'ok candidate', 0, 3, '1,3', '11-1,12-7,13-4,14-3,15-8,16-9,17-3,18-4,19-2,20-5'),
--           ('Dan Hamilton', 'Test Candidate 3', 'casey@gmail.com', 2, 'Information Technology', 0, 3.1, 3.4 , '7-1-2014', '2,4', null, 2, 'not bad', 1, 2, '1,2', '3-4,4-3,5-8,6-9,7-1,8-4,9-2,10-2,11-2,14-3,15-4'),
--           ('Dan Hamilton', 'Test Candidate 4', 'niravs@hotmail.com', 1, 'Computer Science', 0, 3.5, 3.8, '1-1-2015', '1,4', null, 1, 'pretty good candidate', 2, 1, '1', '1-5,2-7,3-4,4-3,5-8,6-9,7-10,8-4,9-2,10-3' )
--GO



-- END iRecruiter Administration Sample Data Database Script 
