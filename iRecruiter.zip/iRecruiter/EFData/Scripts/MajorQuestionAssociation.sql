USE [iRecruiter]
GO

ALTER TABLE [dbo].[MajorQuestionAssociation] DROP CONSTRAINT [FK_MajorQuestionAssociation_Question]
GO

ALTER TABLE [dbo].[MajorQuestionAssociation] DROP CONSTRAINT [FK_MajorQuestionAssociation_Major]
GO

/****** Object:  Table [dbo].[MajorQuestionAssociation]    Script Date: 8/16/2012 10:31:03 AM ******/
DROP TABLE [dbo].[MajorQuestionAssociation]
GO

/****** Object:  Table [dbo].[MajorQuestionAssociation]    Script Date: 8/16/2012 10:31:03 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[MajorQuestionAssociation](
	[MajorQuestionID] [int] IDENTITY(1,1) NOT NULL,
	[MajorID] [int] NOT NULL,
	[QuestionID] [int] NOT NULL,
 CONSTRAINT [PK_MajorQuestionAssociation] PRIMARY KEY CLUSTERED 
(
	[MajorQuestionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[MajorQuestionAssociation]  WITH CHECK ADD  CONSTRAINT [FK_MajorQuestionAssociation_Major] FOREIGN KEY([MajorID])
REFERENCES [dbo].[Major] ([MajorID])
GO

ALTER TABLE [dbo].[MajorQuestionAssociation] CHECK CONSTRAINT [FK_MajorQuestionAssociation_Major]
GO

ALTER TABLE [dbo].[MajorQuestionAssociation]  WITH CHECK ADD  CONSTRAINT [FK_MajorQuestionAssociation_Question] FOREIGN KEY([QuestionID])
REFERENCES [dbo].[Question] ([QuestionID])
GO

ALTER TABLE [dbo].[MajorQuestionAssociation] CHECK CONSTRAINT [FK_MajorQuestionAssociation_Question]
GO

